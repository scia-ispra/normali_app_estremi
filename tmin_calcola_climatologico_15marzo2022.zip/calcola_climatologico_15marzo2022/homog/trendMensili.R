rm(list=objects())
library("tidyverse")
library("guido")
library("climatologici")
library("data.table")
library("broom")

creaCalendario(1961,2020)->calendario

leggi_file(pattern="^.+_cluster._annual_homog_selezionate_per_climatologico_annuale_1991_2020.csv",delim=";",col_names = TRUE,col_types = YYMMDD_TYPE,output = "")->listaDati


purrr::reduce(listaDati,.f=left_join,.init = calendario)->df
ClimateData(df,param = "tmax")->cdati
aggregaCD(cdati,max.na = 10,max.size.block.na = 4,rle.check = TRUE)->mdati
as.data.frame(mdati) %>% setDT()->dati

melt(dati,id.vars = c("yy","mm"),variable.name = "id",value.name = "mensile")[,yy:=.(as.integer(yy))][,mm:=.(as.integer(as.character(mm)))]->dati_long


ggplot(data=dati_long,aes(x=yy,y=mensile))+
  geom_line(aes(group=id))+
  geom_smooth(method = "loess",formula = y~x,na.rm=TRUE,se=FALSE,color="red")+
  geom_smooth(method = "lm",formula = y~x,na.rm=TRUE,se=FALSE,color="blue")+  
  facet_wrap(~mm)+
  theme_bw()


purrr::map_dfr(1:12,.f=function(MESE){
  
  lm(mensile~yy,data=dati_long[mm==MESE])->lmOut
  tidy(lmOut)->ris
  ris$mm<-MESE
  
  ris
  
})->df_lm




