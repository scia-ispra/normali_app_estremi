rm(list=objects())
library("config")
library("tidyverse")
library("climatologici")
library("guido")
library("vroom")
library("janitor")

seq(1961,1991,by=10)->annoInizio
seq(1990,2020,by=10)->annoFine

annoInizio<-c(annoInizio,2001)
annoFine<-c(annoFine,2020)

PARAM<-c("tmax","tmin")[2]

basename(getwd())->tipo_serie #homog o raw

myget<-purrr::partial(.f=config::get,file="climatologico.yml",config="default")



list.files(pattern=glue::glue("^{PARAM}.+serie_valide\\.csv$"))->listaFile
str_remove_all(str_extract(listaFile,pattern = "\\.[a-z]+\\."),"\\.")->clusters #ora nomi delle regioni

purrr::map(listaFile,.f=function(.nomeFile){
  
  vroom(.nomeFile,delim=";",col_names = TRUE,col_types =YYMMDD_TYPE)->dati
  
  ClimateData(dati,param = PARAM)->cdati
  aggregaCD(cdati,max.na = myget(value="max.na"),rle.check = TRUE,max.size.block.na = myget(value="max.size.block.na"))->mensili
 
  purrr::map2(annoInizio,annoFine,.f=function(.yearS,.yearE){
    
    

    climatologiciMensili(mensili,
                         rle.check = FALSE,
                         yearS = .yearS,
                         yearE=.yearE,
                         max.na=myget(value="blocco.anni.na.climatologico"),
                         max.size.block.na = myget(value="max.blocco.anni.na.climatologico")) %>%
      remove_empty(which = "cols")->dati_clim_mensili
    
    if(ncol(dati_clim_mensili)==2) return(list(mensili=NULL,annuali=NULL)) #yy e mm
    
    dati_clim_mensili %>%
      gather(key="id",value="climatologico",-yy,-mm) %>%
      mutate(mese=month.name[mm],mese=factor(mese,levels = month.name,ordered=TRUE)) %>%
      dplyr::select(-mm) %>%
      tidyr::spread(key=mese,value=climatologico)->mensili_finale
    
    
    purrr::map_dfc(dati_clim_mensili %>% select(-yy,-mm),.f=myget(value="fun.climatologico.annuale")) %>%
      remove_empty(which="cols")->dati_clim_annuali

    if(!ncol(dati_clim_annuali)) return(list(mensili=mensili_finale,annuali=NULL))
    

    #if(grepl("basilicata",.nomeFile)) browser()
    
    dati_clim_annuali$yy<-floor(mean(c(.yearE,.yearS)))
    dati_clim_annuali %>% dplyr::select(yy,everything())->dati_clim_annuali

    
    dati_clim_annuali %>%
      gather(key="id",value="climatologico",-yy) %>%
      spread(key=yy,value=climatologico)->annuali_finale
    
    list(mensili=mensili_finale,annuali=annuali_finale)
    
  })->listaClimatologici
  
  
  names(listaClimatologici)<-annoInizio

  listaClimatologici

})->lista_climatologici


names(lista_climatologici)<-clusters


purrr::map(1:4,.f=function(numeroCluster){
  
  purrr::map(lista_climatologici,c(numeroCluster,1)) %>% 
  bind_rows()

}) %>% bind_rows()->dfMensili


write_delim(dfMensili,glue::glue("climatologici_mensili_{PARAM}_{tipo_serie}.csv"),delim=";",col_names = TRUE)



purrr::map(1:4,.f=function(numeroCluster){
  
  
  purrr::map(lista_climatologici,c(numeroCluster,2)) %>% 
    compact() %>%
    bind_rows()
  
}) %>% reduce(.f=full_join,by="id") ->dfAnnuali


write_delim(dfAnnuali,glue::glue("climatologici_annuali_{PARAM}_{tipo_serie}.csv"),delim=";",col_names = TRUE)

