rm(list=objects())
library("config")
library("tidyverse")
library("climatologici")
library("guido")
library("vroom")
library("janitor")

seq(1961,1991,by=10)->annoInizio
seq(1990,2020,by=10)->annoFine



PARAM<-c("tmax","tmin")[1]

basename(getwd())->tipo_serie #homog o raw

myget<-purrr::partial(.f=config::get,file="climatologico.yml",config="default")



list.files(pattern=glue::glue("^{PARAM}_.+[1-9].+selezionate_per_climatologico_annuale_1991_2020\\.csv$"))->listaFile
str_extract(listaFile,pattern = "cluster[0-9]")->clusters

purrr::map(listaFile,.f=function(.nomeFile){
  
  vroom(.nomeFile,delim=";",col_names = TRUE,col_types =YYMMDD_TYPE)->dati
  
  ClimateData(dati,param = PARAM)->cdati
  aggregaCD(cdati,max.na = myget(value="max.na"),rle.check = TRUE,max.size.block.na = myget(value="max.size.block.na"))->mensili
 
  purrr::map2(annoInizio,annoFine,.f=function(.yearS,.yearE){
    

    as.data.frame(mensili) %>% 
      mutate(mm=as.integer(mm)) %>%
      mutate(yy=as.integer(yy)) %>%
      mutate(yy=ifelse(mm==12,yy+1,yy)) %>%
      mutate(seas=case_when(mm %in% c(1,2,12)~"win",
                            mm %in% c(3,4,5)~"spr",
                            mm %in% c(6,7,8)~"sum",
                            mm %in% c(9,10,11)~"aut")) %>%
      filter((yy>= .yearS) & (yy<=.yearE))->dati_mensili
    
    media_annuale<-function(x){
      
      if(length(x)!=30) browser()
      which(is.na(x))->qualiNA
      if(length(qualiNA)>6) return(NA)
      mean(x,na.rm=TRUE)
      
    }
    
    
    dati_mensili %>%
      dplyr::select(-mm) %>%
      group_by(yy,seas) %>%
      summarise(across(.cols=everything(),.fns = mean,na.rm=FALSE))%>%
      ungroup() %>%
      dplyr::select(seas,yy,everything()) %>%
      remove_empty(which="cols") %>%
      dplyr::select(-yy) %>%
      group_by(seas) %>%
      summarise(across(.cols=everything(),.fns=media_annuale)) %>%
      ungroup() %>%
      remove_empty(which="cols")->dati_stagionali
    
  
    if(!ncol(dati_stagionali)) return(list(stagionali=NULL,annuali=NULL))
    
    
    dati_stagionali$yy<-floor(mean(c(.yearE,.yearS)))
    dati_stagionali%>% dplyr::select(yy,seas,everything())->dati_stagionali
    
    
    dati_stagionali %>%
      gather(key="id",value="climatologico",-yy,-seas) %>%
      mutate(seas=factor(seas,levels=c("win","spr","sum","aut"),ordered = TRUE)) %>%
      tidyr::spread(key=seas,value=climatologico)->stagionali_finale
    
    
    list(stagionali=stagionali_finale,annuali=NULL)
    
  })->listaClimatologici
  
  names(listaClimatologici)<-annoInizio
  
  listaClimatologici

})->lista_climatologici

names(lista_climatologici)<-clusters


purrr::map(1:4,.f=function(numeroCluster){
  
  purrr::map(lista_climatologici,c(numeroCluster,1)) %>% 
  bind_rows()

}) %>% bind_rows()->dfStagionali


write_delim(dfStagionali,glue::glue("climatologici_stagionali_{PARAM}_{tipo_serie}.csv"),delim=";",col_names = TRUE)


