rm(list=objects())
library("vroom")
library("tidyverse")
library("data.table")
library("echarts4r")


PARAM<-c("tmax","tmin")[1]
vroom(glue::glue("climatologici_annuali_{PARAM}_homog.csv"),delim=";",col_names = TRUE) %>% setDT()->datiAnnuali
vroom(glue::glue("climatologici_mensili_{PARAM}_homog.csv"),delim=";",col_names = TRUE) %>% setDT()->datiMensili


data.table::melt(data = datiAnnuali,id.vars="id",variable.name="yy",value.name="annuale")[,yy:=as.integer(as.character(yy))]->mdatiAnnuali
merge(datiMensili,mdatiAnnuali,by=c("id","yy"))->dati

melt(dati,id.vars = c("id","yy"),variable.name = "periodo",value.name = "climatologico")[,periodo:=.(factor(periodo,levels = c(month.name,"annuale"),ordered = TRUE))][,climatologico:=.(round(climatologico,2))]->mdati


## Numero delle stazioni per trentennio climatologico

mdati[,.N,keyby=yy]

skimr::skim(mdati %>% group_by(yy))

View(as_tibble(skimr::skim(mdati %>% group_by(yy,periodo))))


e_charts(as.data.frame(mdati) %>% group_by(periodo,yy),x=periodo) %>%
  e_boxplot(serie=climatologico,colorBy="series",tooltip=list(formatter=htmlwidgets::JS("function(params){
    return params.value;
  }"))) %>%
  e_tooltip(trigger="item") %>%
  e_x_axis(axisTick=list(inside=TRUE,length=1000)) 
  
