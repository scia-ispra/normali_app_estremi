rm(list=objects())
library("config")
library("tidyverse")
library("climatologici")
library("guido")
library("vroom")
library("janitor")
library("tidyr")


PARAM<-c("tmax","tmin","tmean","pr")[4]

system(glue::glue("rm -rf climatologici_stagionali_{PARAM}*.csv"))

list.files(pattern=glue::glue("^climatologici_mensili_{PARAM}.+csv$"))->ffile


purrr::walk(ffile,.f=function(nomeFile){
  
  ifelse(grepl("_[gl]t[0-9]+",nomeFile),"sum","mean")->fun_sum
  if(grepl("pr",PARAM,ignore.case = TRUE)) {fun_sum<-"sum"}
  
  aggrega<-function(fun_sum){
    
    function(x){
      

      base::get(fun_sum)(x,na.rm=FALSE)
      
    }
    
  }
  
  aggrega(fun_sum)->sintesi
  
  read_delim(nomeFile,delim=";",col_names = TRUE) %>%
    gather(key="mese",value="climatologico",-yy,-id) %>%
    mutate(mm=match(mese,month.name)) %>%
    mutate(seas=case_when(mm %in% c(1,2,12)~"win",
                          mm %in% c(3,4,5)~"spr",
                          mm %in% c(6,7,8)~"sum",
                          mm %in% c(9,10,11)~"aut")) %>%
    mutate(seas=factor(seas,levels=c("win","spr","sum","aut"),ordered=TRUE))->dati
  
  
  dati %>%
   group_by(yy,id,seas) %>%
    summarise(stagionale=sintesi(climatologico)) %>%
    ungroup() %>%
    spread(key=seas,value = stagionale)->dfStagionali
  
  
  write_delim(dfStagionali,str_replace(nomeFile,"mensili","stagionali"),delim=";",col_names = TRUE)

})
